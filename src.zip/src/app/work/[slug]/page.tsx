import { notFound } from "next/navigation";
import { getProjectBySlug, getAllSlugs } from "@/data/projects";
import { CaseStudyHeader } from "@/components/CaseStudyHeader";
import { FadeIn } from "@/components/FadeIn";
import { ImageWithCaption } from "@/components/ImageWithCaption";
import Link from "next/link";

export function generateStaticParams() {
  return getAllSlugs().map((slug) => ({ slug }));
}

type Params = Promise<{ slug: string }>;

export default async function CaseStudyPage({ params }: { params: Params }) {
  const { slug } = await params;
  const project = getProjectBySlug(slug);
  if (!project) notFound();

  if (slug === "mst") {
    return (
      <>
        <CaseStudyHeader project={project} />

        {/* ══════════════════════════════════════════
            01 · UX RESEARCH
        ══════════════════════════════════════════ */}
        <section id="research" className="border-t border-[#e8e8e8] scroll-mt-24">
          <div className="content-width">
            <div className="grid grid-cols-1 md:grid-cols-[280px_1fr] gap-16 py-16 md:py-24">

              {/* Left — number + section title */}
              <FadeIn>
                <span className="block font-mono text-[10px] tracking-[0.08em] text-[var(--color-muted)] uppercase mb-4">
                  01
                </span>
                <h2 className="text-[32px] md:text-[40px] font-bold tracking-tight leading-[1.1]">
                  UX Research
                </h2>
              </FadeIn>

              {/* Right — all content */}
              <div className="space-y-16">

                {/* Problem + Impact */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-10">
                  <div>
                    <span className="block font-mono text-[9px] tracking-[0.1em] text-[var(--color-muted)] uppercase mb-3">THE PROBLEM</span>
                    <p className="text-[14px] leading-[1.75] text-[var(--color-muted)]">
                      Most e-learning platforms lacked static content or replicate static textbooks without interactivity.
                      Neither approach solves the core problem: students don&apos;t know where they stand, and teachers have no
                      visibility into who is struggling.
                    </p>
                    <p className="text-[14px] leading-[1.75] text-[var(--color-muted)] mt-4">
                      mySecondTeacher set out to change that. The platform introduced diagnostic learning — a structured,
                      curriculum-aligned approach where live feedback is embedded directly with the experience through an
                      interactive video player with quiz checkpoints at every stage.
                    </p>
                  </div>
                  <div>
                    <span className="block font-mono text-[9px] tracking-[0.1em] text-[var(--color-muted)] uppercase mb-3">THE IMPACT</span>
                    <p className="text-[14px] leading-[1.75] text-[var(--color-muted)]">
                      Formal platforms at LMS had serious interfaces. The model product — curriculum-aligned content with
                      diagnostic feedback — was school-grade.
                    </p>
                    <p className="text-[14px] leading-[1.75] text-[var(--color-muted)] mt-4">
                      School platforms at district level offered multiplatform reporting, acting as a first-class feature
                      for compliance. Student excellence drove organic groups.
                    </p>
                  </div>
                </div>

                {/* Competition notes */}
                <div>
                  <span className="block font-mono text-[9px] tracking-[0.1em] text-[var(--color-muted)] uppercase mb-3">COMPETITION NOTES</span>
                  <p className="text-[14px] leading-[1.75] text-[var(--color-muted)] mb-6">
                    International players (Kahn Academy, Khan Academy) fit across Asia. Qualitative research revealed neither
                    of two platforms recruited well — teachers needed a way to manage a full classroom.
                  </p>

                  {/* Competitive table */}
                  <p className="text-[13px] font-semibold mb-4">Understanding the gap we were filling</p>
                  <div className="overflow-x-auto">
                    <table className="w-full text-left text-[13px] border-collapse">
                      <thead>
                        <tr className="border-b border-[#e8e8e8]">
                          {["PRODUCT", "CURRICULUM USED", "ASSESSMENT", "TEACHER TOOLS"].map((h) => (
                            <th key={h} className="pb-3 pr-8 font-mono text-[9px] tracking-[0.08em] text-[var(--color-muted)] uppercase font-medium">
                              {h}
                            </th>
                          ))}
                        </tr>
                      </thead>
                      <tbody>
                        {[
                          ["mySecondTeacher", "National aligned", "Yes — embedded", "Classroom tools"],
                          ["Khan Academy", "Self-structured", "Basic quizzes", "No school portal"],
                          ["Unacademy", "Curated content", "Basic quizzes", "Teacher, only"],
                          ["mySecondTeacher", "Curriculum-aligned", "UX embedded", "Classroom tools"],
                        ].map((row, i) => (
                          <tr key={i} className="border-b border-[#f5f5f5]">
                            {row.map((cell, j) => (
                              <td key={j} className={`py-3.5 pr-8 text-[13px] ${j === 0 ? "font-semibold text-[var(--color-text)]" : "text-[var(--color-muted)]"}`}>
                                {cell}
                              </td>
                            ))}
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>

                {/* Empathy map */}
                <div>
                  <span className="block font-mono text-[9px] tracking-[0.1em] text-[var(--color-muted)] uppercase mb-6">EMPATHY MAP</span>
                  <div className="space-y-6">
                    {/* Persona 1 */}
                    <div>
                      <p className="text-[13px] font-semibold mb-4">Persona 1: Student</p>
                      <div className="grid grid-cols-2 gap-0 border border-[#e8e8e8]">
                        {[
                          { q: "THINKS", a: "Online classes that are frequent & informal in a home" },
                          { q: "FEELS", a: "Understated self-worth without guidance" },
                          { q: "SAYS", a: "\"Saagu fariyuh videos, tiyono internetchai\"" },
                          { q: "DOES", a: "\"I want to know where I stand\"" },
                        ].map(({ q, a }) => (
                          <div key={q} className="p-5 border-b border-r border-[#e8e8e8] last:border-b-0">
                            <span className="block font-mono text-[9px] tracking-[0.08em] text-[var(--color-muted)] uppercase mb-2">{q}</span>
                            <p className="text-[13px] text-[var(--color-muted)] leading-[1.6]">{a}</p>
                          </div>
                        ))}
                      </div>
                    </div>

                    {/* Persona 2 */}
                    <div>
                      <p className="text-[13px] font-semibold mb-4">Persona 2: Teacher</p>
                      <div className="grid grid-cols-2 gap-0 border border-[#e8e8e8]">
                        {[
                          { q: "THINKS", a: "\"I spent who's doing Saagu fariyuh into the exam\"" },
                          { q: "FEELS", a: "Burdened by manual tracking & admin overhead" },
                          { q: "SAYS", a: "\"I spend time on anything but teaching, otherwise\"" },
                          { q: "DOES", a: "\"Since she works on anything-else, not other\"" },
                        ].map(({ q, a }) => (
                          <div key={q} className="p-5 border-b border-r border-[#e8e8e8] last:border-b-0">
                            <span className="block font-mono text-[9px] tracking-[0.08em] text-[var(--color-muted)] uppercase mb-2">{q}</span>
                            <p className="text-[13px] text-[var(--color-muted)] leading-[1.6]">{a}</p>
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>
                </div>

              </div>
            </div>
          </div>
        </section>

        {/* ══════════════════════════════════════════
            02 · UX DESIGN
        ══════════════════════════════════════════ */}
        <section id="ux-design" className="border-t border-[#e8e8e8] scroll-mt-24">
          <div className="content-width">
            <div className="grid grid-cols-1 md:grid-cols-[280px_1fr] gap-16 py-16 md:py-24">

              <FadeIn>
                <span className="block font-mono text-[10px] tracking-[0.08em] text-[var(--color-muted)] uppercase mb-4">02</span>
                <h2 className="text-[32px] md:text-[40px] font-bold tracking-tight leading-[1.1]">UX Design</h2>
              </FadeIn>

              <div className="space-y-16">

                {/* Value proposition table */}
                <div>
                  <span className="block font-mono text-[9px] tracking-[0.1em] text-[var(--color-muted)] uppercase mb-4">VALUE PROPOSITION MAP</span>
                  <div className="overflow-x-auto">
                    <table className="w-full text-left text-[13px] border-collapse">
                      <thead>
                        <tr className="border-b border-[#e8e8e8]">
                          {["CUSTOMER JOB", "PAINS", "GAINS"].map((h) => (
                            <th key={h} className="pb-3 pr-8 font-mono text-[9px] tracking-[0.08em] text-[var(--color-muted)] uppercase font-medium">{h}</th>
                          ))}
                        </tr>
                      </thead>
                      <tbody>
                        {[
                          ["Learn at my own pace", "Passive video", "Embedded quiz feedback"],
                          ["Track student progress", "No real-time view", "Live analytics dashboard"],
                          ["Manage school admin", "Paper-based admin", "Digital admin tools"],
                        ].map((row, i) => (
                          <tr key={i} className="border-b border-[#f5f5f5]">
                            <td className="py-3.5 pr-8 font-semibold text-[var(--color-text)] text-[13px]">{row[0]}</td>
                            <td className="py-3.5 pr-8 text-[var(--color-muted)] text-[13px]">{row[1]}</td>
                            <td className="py-3.5 pr-8 text-[var(--color-muted)] text-[13px]">{row[2]}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>

                {/* Feature matrix */}
                <div>
                  <span className="block font-mono text-[9px] tracking-[0.1em] text-[var(--color-muted)] uppercase mb-4">FEATURE MATRIX</span>
                  <div className="overflow-x-auto">
                    <table className="w-full text-left text-[13px] border-collapse">
                      <thead>
                        <tr className="border-b border-[#e8e8e8]">
                          {["FEATURE", "ROLE", "BUILD", "EFFORT"].map((h) => (
                            <th key={h} className="pb-3 pr-8 font-mono text-[9px] tracking-[0.08em] text-[var(--color-muted)] uppercase font-medium">{h}</th>
                          ))}
                        </tr>
                      </thead>
                      <tbody>
                        {[
                          ["Video player + quiz", "Student", "Core", "HIGH"],
                          ["Curriculum align", "Admin", "Build", "MED"],
                          ["Interactive objects concept", "Admin", "Core and modules", "LOW"],
                          ["Scoring summary on completion", "Admin", "Core plus progress checkpoint", "MED"],
                        ].map((row, i) => (
                          <tr key={i} className="border-b border-[#f5f5f5]">
                            <td className="py-3.5 pr-8 font-semibold text-[var(--color-text)] text-[13px]">{row[0]}</td>
                            <td className="py-3.5 pr-8 text-[var(--color-muted)] text-[13px]">{row[1]}</td>
                            <td className="py-3.5 pr-8 text-[var(--color-muted)] text-[13px]">{row[2]}</td>
                            <td className="py-3.5 pr-8 text-[var(--color-muted)] text-[13px]">{row[3]}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>

                {/* IA — ecosystem */}
                <div>
                  <span className="block font-mono text-[9px] tracking-[0.1em] text-[var(--color-muted)] uppercase mb-3">INFORMATION ARCHITECTURE</span>
                  <p className="text-[14px] leading-[1.75] text-[var(--color-muted)] mb-8">
                    Designed for students, teachers, and parents across multiple products: mySecondTeacher, Apollo LMS, and
                    OTT video player, eBook reader, and Teachers module with a vetted component library.
                  </p>

                  {/* Ecosystem diagram */}
                  <div className="border border-[#e8e8e8] p-6 mb-8">
                    <div className="flex justify-center mb-6">
                      <span className="bg-black text-white font-mono text-[10px] tracking-widest uppercase py-2 px-5">
                        mySecondTeacher ecosystem
                      </span>
                    </div>
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-px bg-[#e8e8e8]">
                      {[
                        {
                          portal: "Student portal",
                          items: ["Overview from on Dashboard", "Classroom Library", "Course Atlas Elder Lessons", "Diagnostic Report", "Progress Tracker"],
                        },
                        {
                          portal: "Teacher portal",
                          items: ["Dashboard", "Code Semester", "Assignments", "Multiset Analytics", "Course Library"],
                        },
                        {
                          portal: "BackOffice",
                          items: ["User management", "School management", "Course Management", "KYI API", "Grade AP"],
                        },
                        {
                          portal: "JiCloud Flow",
                          items: ["Localised Content", "Interactive Module"],
                        },
                      ].map(({ portal, items }) => (
                        <div key={portal} className="bg-white p-5">
                          <span className="block font-mono text-[9px] tracking-[0.08em] text-[var(--color-text)] uppercase font-semibold mb-3">
                            {portal}
                          </span>
                          <ul className="space-y-2">
                            {items.map((item) => (
                              <li key={item} className="text-[12px] text-[var(--color-muted)] leading-snug">{item}</li>
                            ))}
                          </ul>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* IA table */}
                  <div className="overflow-x-auto">
                    <table className="w-full text-left text-[13px] border-collapse">
                      <thead>
                        <tr className="border-b border-[#e8e8e8]">
                          {["MODULE", "SUB-MODULE", "PLATFORM", "USER ROLE"].map((h) => (
                            <th key={h} className="pb-3 pr-8 font-mono text-[9px] tracking-[0.08em] text-[var(--color-muted)] uppercase font-medium">{h}</th>
                          ))}
                        </tr>
                      </thead>
                      <tbody>
                        {[
                          ["Dashboard", "Analytics, Assignments, Feedback", "Web, Mobile", "Teacher, Admin"],
                          ["Learning Space", "Videos, Interactive Quizzes, Notes", "Web, Mobile, App", "Student"],
                          ["Assessment", "Auto-grading, Performance Reports", "Web", "Teacher, Parent"],
                          ["Content Library", "Lessons, eBooks, OTT Video", "All platforms", "Student, Teacher"],
                        ].map((row, i) => (
                          <tr key={i} className="border-b border-[#f5f5f5]">
                            <td className="py-3.5 pr-8 font-semibold text-[var(--color-text)] text-[13px]">{row[0]}</td>
                            <td className="py-3.5 pr-8 text-[var(--color-muted)] text-[13px]">{row[1]}</td>
                            <td className="py-3.5 pr-8 text-[var(--color-muted)] text-[13px]">{row[2]}</td>
                            <td className="py-3.5 pr-8 text-[var(--color-muted)] text-[13px]">{row[3]}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>

              </div>
            </div>
          </div>
        </section>

        {/* ══════════════════════════════════════════
            03 · UI DESIGN
        ══════════════════════════════════════════ */}
        <section id="ui-design" className="border-t border-[#e8e8e8] scroll-mt-24">
          <div className="content-width">
            <div className="grid grid-cols-1 md:grid-cols-[280px_1fr] gap-16 py-16 md:py-24">

              <FadeIn>
                <span className="block font-mono text-[10px] tracking-[0.08em] text-[var(--color-muted)] uppercase mb-4">03</span>
                <h2 className="text-[32px] md:text-[40px] font-bold tracking-tight leading-[1.1]">UI Design</h2>
              </FadeIn>

              <div className="space-y-12">
                <div>
                  <span className="block font-mono text-[9px] tracking-[0.1em] text-[var(--color-muted)] uppercase mb-4">KEY SCREENS</span>
                  <p className="text-[14px] leading-[1.75] text-[var(--color-muted)] mb-10">
                    Designed for students, teachers, and parents across multiple products: mySecondTeacher, Apollo LMS, and OTT
                    video player, eBook reader, and Teachers module with a vetted component library.
                  </p>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <ImageWithCaption src="/images/mst/screen-student-dashboard.png" alt="Student Dashboard" caption="Centralized learning dashboard for students." />
                  <ImageWithCaption src="/images/mst/screen-video-player.png" alt="Video Player" caption="Video player with embedded quiz checkpoints." />
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <ImageWithCaption src="/images/mst/screen-teacher-dashboard.png" alt="Teacher Dashboard" caption="Real-time analytics and class management." />
                  <ImageWithCaption src="/images/mst/screen-quiz.png" alt="Quiz Interface" caption="Diagnostic assessments with instant feedback." />
                </div>
              </div>

            </div>
          </div>
        </section>

        {/* ══════════════════════════════════════════
            04 · KEY OUTCOMES
        ══════════════════════════════════════════ */}
        <section id="outcomes" className="border-t border-[#e8e8e8] scroll-mt-24">
          <div className="content-width">
            <div className="grid grid-cols-1 md:grid-cols-[280px_1fr] gap-16 py-16 md:py-24">

              <FadeIn>
                <span className="block font-mono text-[10px] tracking-[0.08em] text-[var(--color-muted)] uppercase mb-4">04</span>
                <h2 className="text-[32px] md:text-[40px] font-bold tracking-tight leading-[1.1]">Key Outcomes</h2>
              </FadeIn>

              <div className="space-y-14">
                <div>
                  <span className="block font-mono text-[9px] tracking-[0.1em] text-[var(--color-muted)] uppercase mb-6">KEY METRICS</span>
                  <ul className="space-y-4">
                    {[
                      "Successfully integrated with Google Classroom ecosystem.",
                      "Adopted by 500+ schools across Nepal and SE Asia.",
                      "Reduced teacher administrative workload by approximately 30%.",
                      "Achieved a 4.8/5 rating on the App Store with 100k+ downloads.",
                    ].map((item) => (
                      <li key={item} className="flex items-start gap-3 text-[15px] md:text-[17px] font-semibold leading-snug">
                        <span className="mt-2 w-1.5 h-1.5 rounded-full bg-black flex-shrink-0" />
                        {item}
                      </li>
                    ))}
                  </ul>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-10 pt-8 border-t border-[#e8e8e8]">
                  <div>
                    <h3 className="text-[15px] font-bold mb-3">Reflection</h3>
                    <p className="text-[var(--color-muted)] text-[14px] leading-[1.75]">
                      Building for emerging markets taught me that accessibility isn&apos;t just about UI — it&apos;s about
                      understanding physical constraints like battery life and data costs.
                    </p>
                  </div>
                  <div>
                    <h3 className="text-[15px] font-bold mb-3">Moving forward</h3>
                    <p className="text-[var(--color-muted)] text-[14px] leading-[1.75]">
                      In the next phase, we would focus on AI-driven personalized learning paths to further improve
                      student engagement.
                    </p>
                  </div>
                </div>

                <div className="pt-8 border-t border-[#e8e8e8]">
                  <span className="block font-mono text-[9px] tracking-[0.1em] text-[var(--color-muted)] uppercase mb-4">NEXT PROJECT</span>
                  <Link
                    href="/work/meromomma/"
                    className="text-[28px] md:text-[36px] font-bold tracking-tight text-black hover:opacity-50 transition-opacity no-underline"
                  >
                    Meromomma →
                  </Link>
                </div>
              </div>

            </div>
          </div>
        </section>
      </>
    );
  }

  // ── Generic fallback ──
  return (
    <>
      <CaseStudyHeader project={project} />
      <section id="research" className="border-t border-[#e8e8e8] scroll-mt-24">
        <div className="content-width">
          <div className="grid grid-cols-1 md:grid-cols-[280px_1fr] gap-16 py-16 md:py-24">
            <FadeIn>
              <span className="block font-mono text-[10px] tracking-[0.08em] text-[var(--color-muted)] uppercase mb-4">01</span>
              <h2 className="text-[32px] font-bold tracking-tight">UX Research</h2>
            </FadeIn>
            <div className="space-y-16 max-w-[680px]">
              <ImageWithCaption src={`/images/${project.slug}/empathy-map.png`} alt="Empathy map" caption="Pain points and needs per user type." />
              <ImageWithCaption src={`/images/${project.slug}/journey-map.png`} alt="Journey map" caption="End-to-end experience arc." />
            </div>
          </div>
        </div>
      </section>
      <section id="ux-design" className="border-t border-[#e8e8e8] scroll-mt-24">
        <div className="content-width">
          <div className="grid grid-cols-1 md:grid-cols-[280px_1fr] gap-16 py-16 md:py-24">
            <FadeIn>
              <span className="block font-mono text-[10px] tracking-[0.08em] text-[var(--color-muted)] uppercase mb-4">02</span>
              <h2 className="text-[32px] font-bold tracking-tight">UX Design</h2>
            </FadeIn>
            <div className="space-y-16 max-w-[680px]">
              <ImageWithCaption src={`/images/${project.slug}/ia-sitemap.png`} alt="IA sitemap" caption="Product structure and navigation hierarchy." />
              <div className="border-l-2 border-black pl-8 py-2">
                <h3 className="text-[15px] font-bold mb-3">Key decision</h3>
                <p className="text-[var(--color-muted)] text-[14px] leading-[1.75]">
                  We chose to unify the portal experience to reduce maintenance overhead and improve cross-service discovery.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>
      <section id="ui-design" className="border-t border-[#e8e8e8] scroll-mt-24">
        <div className="content-width">
          <div className="grid grid-cols-1 md:grid-cols-[280px_1fr] gap-16 py-16 md:py-24">
            <FadeIn>
              <span className="block font-mono text-[10px] tracking-[0.08em] text-[var(--color-muted)] uppercase mb-4">03</span>
              <h2 className="text-[32px] font-bold tracking-tight">UI Design</h2>
            </FadeIn>
            <div className="space-y-8 max-w-[680px]">
              {[1, 2, 3].map((n) => (
                <ImageWithCaption key={n} src={`/images/${project.slug}/screen-${n}.png`} alt={`Screen ${n}`} caption={`Core interface screen ${n}.`} />
              ))}
            </div>
          </div>
        </div>
      </section>
      <section id="outcomes" className="border-t border-[#e8e8e8] scroll-mt-24">
        <div className="content-width">
          <div className="grid grid-cols-1 md:grid-cols-[280px_1fr] gap-16 py-16 md:py-24">
            <FadeIn>
              <span className="block font-mono text-[10px] tracking-[0.08em] text-[var(--color-muted)] uppercase mb-4">04</span>
              <h2 className="text-[32px] font-bold tracking-tight">Key Outcomes</h2>
            </FadeIn>
            <div className="space-y-12 max-w-[680px]">
              <p className="text-[32px] font-bold leading-tight tracking-tight">{project.topOutcome}</p>
              <div className="pt-8 border-t border-[#e8e8e8]">
                <span className="block font-mono text-[9px] tracking-[0.1em] text-[var(--color-muted)] uppercase mb-4">NEXT PROJECT</span>
                <Link href="/work/mst/" className="text-[28px] font-bold tracking-tight text-black hover:opacity-50 transition-opacity no-underline">
                  mySecondTeacher →
                </Link>
              </div>
            </div>
          </div>
        </div>
      </section>
    </>
  );
}