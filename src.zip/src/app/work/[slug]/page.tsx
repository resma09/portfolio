import { notFound } from "next/navigation";
import { getProjectBySlug, getAllSlugs } from "@/data/projects";
import { CaseStudyHeader } from "@/components/CaseStudyHeader";
import { ProcessNav } from "@/components/ProcessNav";
import { FadeIn } from "@/components/FadeIn";
import { ImageWithCaption } from "@/components/ImageWithCaption";
import Link from "next/link";

// Generate static paths for all 7 projects
export function generateStaticParams() {
  return getAllSlugs().map((slug) => ({ slug }));
}

type Params = Promise<{ slug: string }>;

export default async function CaseStudyPage({
  params,
}: {
  params: Params;
}) {
  const { slug } = await params;
  const project = getProjectBySlug(slug);

  if (!project) {
    notFound();
  }

  return (
    <>
      <CaseStudyHeader project={project} />
      <ProcessNav />

      {/* ── Research ── */}
      <section id="research" className="scroll-mt-32">
        <div className="content-width">
          <FadeIn>
            <h2 className="font-[family-name:var(--font-heading)] text-3xl mb-4">
              Research
            </h2>
            <p className="text-[var(--color-muted)] mb-10 max-w-[540px]">
              Understanding the problem space before touching a screen.
            </p>
          </FadeIn>

          {/* Context */}
          <FadeIn>
            <div className="mb-12">
              <h3 className="font-medium text-lg mb-3">Context</h3>
              <p className="text-[var(--color-muted)] leading-relaxed">
                {/* Replace with actual project context */}
                [Project context — background, landscape, project goals. Write
                2-3 sentences about what the situation was when this project
                started.]
              </p>
            </div>
          </FadeIn>

          {/* Empathy Map */}
          <FadeIn>
            <div className="mb-12">
              <h3 className="font-medium text-lg mb-3">Empathy map</h3>
              <p className="text-sm text-[var(--color-muted)] mb-4">
                Pain points, behaviors, and needs per user type.
              </p>
              <ImageWithCaption
                src={`/images/${project.slug}/empathy-map.png`}
                alt={`Empathy map — ${project.title}`}
                caption="Empathy map showing user pain points across key user types"
                wide
              />
            </div>
          </FadeIn>

          {/* User Journey Map */}
          <FadeIn>
            <div className="mb-12">
              <h3 className="font-medium text-lg mb-3">User journey map</h3>
              <p className="text-sm text-[var(--color-muted)] mb-4">
                End-to-end experience arc across touchpoints.
              </p>
              <ImageWithCaption
                src={`/images/${project.slug}/journey-map.png`}
                alt={`User journey map — ${project.title}`}
                caption="Journey map showing the full user experience"
                wide
              />
            </div>
          </FadeIn>

          {/* Research Findings */}
          <FadeIn>
            <div className="mb-12">
              <h3 className="font-medium text-lg mb-6">Research findings</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {/* Replace with actual findings */}
                {["Finding 1", "Finding 2", "Finding 3", "Finding 4"].map(
                  (finding, i) => (
                    <div
                      key={i}
                      className="border border-[var(--color-border)] rounded-lg p-5"
                    >
                      <p className="font-medium text-sm mb-1">
                        {finding} title
                      </p>
                      <p className="text-sm text-[var(--color-muted)]">
                        [Short, specific insight from research]
                      </p>
                    </div>
                  )
                )}
              </div>
            </div>
          </FadeIn>
        </div>
      </section>

      {/* ── UX Design ── */}
      <section id="ux-design" className="scroll-mt-32">
        <div className="content-width">
          <FadeIn>
            <h2 className="font-[family-name:var(--font-heading)] text-3xl mb-4">
              UX Design
            </h2>
            <p className="text-[var(--color-muted)] mb-10 max-w-[540px]">
              Structuring the product and making scope decisions.
            </p>
          </FadeIn>

          {/* Value Canvas */}
          <FadeIn>
            <div className="mb-12">
              <h3 className="font-medium text-lg mb-3">Value canvas</h3>
              <p className="text-sm text-[var(--color-muted)] mb-4">
                What value the product delivers to each user type.
              </p>
              <ImageWithCaption
                src={`/images/${project.slug}/value-canvas.png`}
                alt={`Value canvas — ${project.title}`}
                caption="Value canvas mapping product value to user types"
                wide
              />
            </div>
          </FadeIn>

          {/* IA Sitemap */}
          <FadeIn>
            <div className="mb-12">
              <h3 className="font-medium text-lg mb-3">
                Information architecture
              </h3>
              <p className="text-sm text-[var(--color-muted)] mb-4">
                Product structure — portals, modules, navigation hierarchy.
              </p>
              <ImageWithCaption
                src={`/images/${project.slug}/ia-sitemap.png`}
                alt={`IA sitemap — ${project.title}`}
                caption="Information architecture showing the product structure"
                wide
              />
            </div>
          </FadeIn>

          {/* Feature Roadmap */}
          <FadeIn>
            <div className="mb-12">
              <h3 className="font-medium text-lg mb-3">Feature roadmap</h3>
              <p className="text-sm text-[var(--color-muted)] mb-4">
                What we built first and why.
              </p>
              <ImageWithCaption
                src={`/images/${project.slug}/roadmap.png`}
                alt={`Feature roadmap — ${project.title}`}
                caption="Phased roadmap showing prioritization decisions"
                wide
              />
            </div>
          </FadeIn>

          {/* Wireframes */}
          <FadeIn>
            <div className="mb-12">
              <h3 className="font-medium text-lg mb-3">Wireframes</h3>
              <p className="text-sm text-[var(--color-muted)] mb-4">
                Progression from low-fidelity to mid-fidelity.
              </p>
              <ImageWithCaption
                src={`/images/${project.slug}/wireframes.png`}
                alt={`Wireframes — ${project.title}`}
                caption="Lo-fi to mid-fi wireframe progression"
                wide
              />
            </div>
          </FadeIn>

          {/* Key Decision */}
          <FadeIn>
            <div className="mb-12 border-l-2 border-[var(--color-accent)] pl-6">
              <h3 className="font-medium text-lg mb-2">Key decision</h3>
              <p className="text-[var(--color-muted)] leading-relaxed">
                [Describe a tradeoff: &quot;We had X constraint, so we chose Y
                over Z because...&quot; — This is where process leadership
                shows.]
              </p>
            </div>
          </FadeIn>
        </div>
      </section>

      {/* ── UI Design ── */}
      <section id="ui-design" className="scroll-mt-32">
        <div className="content-width">
          <FadeIn>
            <h2 className="font-[family-name:var(--font-heading)] text-3xl mb-4">
              UI Design
            </h2>
            <p className="text-[var(--color-muted)] mb-10 max-w-[540px]">
              Visual execution and design system.
            </p>
          </FadeIn>

          {/* Design System */}
          <FadeIn>
            <div className="mb-12">
              <h3 className="font-medium text-lg mb-3">Design system</h3>
              <ImageWithCaption
                src={`/images/${project.slug}/design-system.png`}
                alt={`Design system — ${project.title}`}
                caption="Component highlights and patterns"
                wide
              />
            </div>
          </FadeIn>

          {/* Key Screens */}
          <FadeIn>
            <div className="mb-12">
              <h3 className="font-medium text-lg mb-6">Key screens</h3>
              <div className="space-y-8">
                {[1, 2, 3].map((n) => (
                  <ImageWithCaption
                    key={n}
                    src={`/images/${project.slug}/screen-${n}.png`}
                    alt={`Key screen ${n} — ${project.title}`}
                    caption={`[Screen ${n} description — what this screen shows and why it matters]`}
                    wide
                  />
                ))}
              </div>
            </div>
          </FadeIn>
        </div>
      </section>

      {/* ── Outcomes ── */}
      <section id="outcomes" className="scroll-mt-32">
        <div className="content-width">
          <FadeIn>
            <h2 className="font-[family-name:var(--font-heading)] text-3xl mb-4">
              Outcomes
            </h2>
          </FadeIn>

          {/* Top outcome callout */}
          <FadeIn>
            <div className="bg-[var(--color-border)]/30 rounded-lg p-8 mb-10">
              <p className="text-sm text-[var(--color-muted)] mb-1">
                Top outcome
              </p>
              <p className="font-[family-name:var(--font-heading)] text-2xl text-[var(--color-accent)]">
                {project.topOutcome}
              </p>
            </div>
          </FadeIn>

          {/* Reflection */}
          <FadeIn>
            <div className="mb-10 space-y-6">
              <div>
                <h3 className="font-medium text-lg mb-2">Reflection</h3>
                <p className="text-[var(--color-muted)] leading-relaxed">
                  [What the process taught the team — 2-3 sentences about the
                  biggest learning from this project.]
                </p>
              </div>
              <div>
                <h3 className="font-medium text-lg mb-2">
                  What I&apos;d do differently
                </h3>
                <p className="text-[var(--color-muted)] leading-relaxed">
                  [1-2 sentences — shows self-awareness and growth.]
                </p>
              </div>
            </div>
          </FadeIn>

          {/* Next project link */}
          <FadeIn>
            <div className="border-t border-[var(--color-border)] pt-8 mt-16">
              <p className="text-sm text-[var(--color-muted)] mb-2">
                Next project
              </p>
              <Link
                href="/work/mst/"
                className="font-[family-name:var(--font-heading)] text-2xl text-[var(--color-text)] hover:text-[var(--color-accent)] transition-colors no-underline"
              >
                mySecondTeacher →
              </Link>
            </div>
          </FadeIn>
        </div>
      </section>
    </>
  );
}
