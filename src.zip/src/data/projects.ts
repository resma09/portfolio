export type Project = {
  slug: string;
  title: string;
  industry: string;
  tagline: string;
  coverImage: string;
  featured: boolean;
  role: string;
};

export const projects: Project[] = [
  {
    slug: "mst",
    title: "mySecondTeacher",
    industry: "ED-TECH",
    tagline:
      "Designing a multi-role learning platform that scaled across Nepal and Southeast Asia.",
    coverImage: "/images/mst-featured-thumb.png",
    featured: true,
    role: "Design Team Lead",
  },
  {
    slug: "meromomma",
    title: "Meromomma",
    industry: "CONSUMER",
    tagline:
      "Building a pregnancy and parenting platform that brings health tools, shopping, community, and expert access together for Nepali parents.",
    coverImage: "/images/meromomma-featured-thumb.png",
    featured: true,
    role: "Project Manager",
  },
  {
    slug: "medilink",
    title: "Medilink Network",
    industry: "HEALTHCARE",
    tagline:
      "Unifying six fragmented healthcare portals into one consistent, trustworthy ecosystem for patients, doctors, and providers.",
    coverImage: "/images/medilink-featured-thumb.png",
    featured: true,
    role: "Design Team Lead",
  },
  {
    slug: "inova",
    title: "Inova DD",
    industry: "BIO PHARMA",
    tagline:
      "Redesigning a legacy biopharma compliance platform — replacing document-heavy workflows with a structured, intuitive system.",
    coverImage: "/images/inova-featured-thumb.png",
    featured: true,
    role: "Project Manager",
  },
];

export function getFeaturedProjects(): Project[] {
  return projects.filter((p) => p.featured);
}

export function getProjectBySlug(slug: string): Project | undefined {
  return projects.find((p) => p.slug === slug);
}

export function getAllSlugs(): string[] {
  return projects.map((p) => p.slug);
}

