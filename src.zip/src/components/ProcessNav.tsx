"use client";

import { useEffect, useState } from "react";

const sections = [
  { id: "research", label: "Research" },
  { id: "ux-design", label: "UX Design" },
  { id: "ui-design", label: "UI Design" },
  { id: "outcomes", label: "Outcomes" },
];

export function ProcessNav() {
  const [active, setActive] = useState("research");

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            setActive(entry.target.id);
          }
        });
      },
      { rootMargin: "-40% 0px -50% 0px" }
    );

    sections.forEach(({ id }) => {
      const el = document.getElementById(id);
      if (el) observer.observe(el);
    });

    return () => observer.disconnect();
  }, []);

  const scrollTo = (id: string) => {
    const el = document.getElementById(id);
    if (el) {
      el.scrollIntoView({ behavior: "smooth", block: "start" });
    }
  };

  return (
    <nav className="sticky top-16 z-40 border-b border-[var(--color-border)] bg-[var(--color-bg)]/95 backdrop-blur-sm">
      <div className="content-width flex gap-1 overflow-x-auto py-3">
        {sections.map(({ id, label }) => (
          <button
            key={id}
            onClick={() => scrollTo(id)}
            className={`text-sm whitespace-nowrap px-4 py-1.5 rounded-full transition-colors ${
              active === id
                ? "bg-[var(--color-text)] text-[var(--color-bg)]"
                : "text-[var(--color-muted)] hover:text-[var(--color-text)]"
            }`}
          >
            {label}
          </button>
        ))}
      </div>
    </nav>
  );
}
