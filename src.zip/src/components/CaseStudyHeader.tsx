import Image from "next/image";
import type { Project } from "@/data/projects";

type Props = { project: Project };

export function CaseStudyHeader({ project }: Props) {
  return (
    <header className="pt-32 md:pt-40">

      {/* Title block */}
      <div className="content-width mb-10">
        <span className="block font-mono text-[10px] tracking-[0.08em] text-[var(--color-muted)] uppercase mb-5">
          {project.industry}
        </span>
        <h1 className="text-[36px] md:text-[48px] font-bold leading-[1.08] tracking-tight max-w-[680px] mb-5">
          {project.title}
        </h1>
        <p className="text-[var(--color-muted)] text-[15px] leading-[1.7] max-w-[520px]">
          {project.tagline}
        </p>
      </div>

      {/* Full-bleed cover image */}
      <div className="w-full aspect-[16/8] bg-[#f2f2f2] overflow-hidden relative">
        <Image
          src={project.coverImage}
          alt={project.title}
          fill
          priority
          className="object-cover"
        />
      </div>

      {/* Metadata row */}
      <div className="content-width">
        <div className="grid grid-cols-2 md:grid-cols-4 border-b border-[#e8e8e8]">
          {[
            { label: "ROLE", value: project.role },
            { label: "TIMELINE", value: project.timeline },
            { label: "TOOLS / USE", value: project.tools },
            { label: "TOOLS", value: project.deliverable },
          ].map(({ label, value }) => (
            <div key={label} className="py-5 pr-8 border-r border-[#e8e8e8] last:border-r-0">
              <span className="block font-mono text-[9px] tracking-[0.1em] text-[var(--color-muted)] uppercase mb-1.5">
                {label}
              </span>
              <p className="text-[var(--color-text)] text-[13px] font-semibold">
                {value}
              </p>
            </div>
          ))}
        </div>

        {/* Process nav tabs */}
        <div className="flex gap-0 border-b border-[#e8e8e8] mt-0">
          {[
            { label: "UX RESEARCH", href: "#research" },
            { label: "UX DESIGN", href: "#ux-design" },
            { label: "UI DESIGN", href: "#ui-design" },
            { label: "KEY OUTCOMES", href: "#outcomes" },
          ].map(({ label, href }) => (
            <a
              key={label}
              href={href}
              className="font-mono text-[10px] tracking-[0.08em] text-[var(--color-muted)] uppercase py-4 pr-8 hover:text-[var(--color-text)] transition-colors no-underline"
            >
              {label}
            </a>
          ))}
        </div>
      </div>

    </header>
  );
}