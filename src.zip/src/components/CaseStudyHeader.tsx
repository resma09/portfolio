import type { Project } from "@/data/projects";

type CaseStudyHeaderProps = {
  project: Project;
};

export function CaseStudyHeader({ project }: CaseStudyHeaderProps) {
  return (
    <header className="pt-12 pb-8">
      {/* Hero image placeholder */}
      <div className="image-width mb-10">
        <div className="aspect-[16/9] bg-[var(--color-border)] rounded-lg flex items-center justify-center text-[var(--color-muted)]">
          Cover image — {project.title}
        </div>
      </div>

      <div className="content-width">
        <div className="flex flex-wrap gap-2 mb-3">
          {project.industry.map((tag) => (
            <span
              key={tag}
              className="text-xs text-[var(--color-muted)] border border-[var(--color-border)] rounded-full px-3 py-0.5"
            >
              {tag}
            </span>
          ))}
        </div>

        <h1 className="font-[family-name:var(--font-heading)] text-4xl md:text-5xl mb-4">
          {project.title}
        </h1>

        <p className="text-lg text-[var(--color-muted)] mb-8 max-w-[540px]">
          {project.tagline}
        </p>

        {/* Overview details grid */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-6 text-sm border-t border-[var(--color-border)] pt-6">
          <div>
            <p className="text-[var(--color-muted)] mb-1">Timeline</p>
            <p>{project.timeline}</p>
          </div>
          <div>
            <p className="text-[var(--color-muted)] mb-1">Role</p>
            <p>{project.role}</p>
          </div>
          <div>
            <p className="text-[var(--color-muted)] mb-1">Team</p>
            <p>{project.team}</p>
          </div>
          <div>
            <p className="text-[var(--color-muted)] mb-1">Outcome</p>
            <p className="text-[var(--color-accent)] font-medium">
              {project.topOutcome}
            </p>
          </div>
        </div>
      </div>
    </header>
  );
}
