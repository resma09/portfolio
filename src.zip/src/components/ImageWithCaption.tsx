type ImageWithCaptionProps = {
  src: string;
  alt: string;
  caption?: string;
  wide?: boolean;
};

export function ImageWithCaption({
  src,
  alt,
  caption,
  wide = false,
}: ImageWithCaptionProps) {
  return (
    <figure className={`my-10 ${wide ? "image-width" : "content-width"}`}>
      {/* Replace placeholder with actual Image component when you have images */}
      <div className="aspect-[16/10] bg-[var(--color-border)] rounded-lg flex items-center justify-center text-[var(--color-muted)] text-sm">
        {alt}
      </div>
      {caption && (
        <figcaption className="text-xs text-[var(--color-muted)] mt-3 text-center">
          {caption}
        </figcaption>
      )}
    </figure>
  );
}
